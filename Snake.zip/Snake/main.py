import sys
import pygame
from pygame.math import Vector2
import snake

main_game = snake.MAIN()

pygame.display.set_caption("Rắn săn mồi")
icon = pygame.image.load("Graphics/home1.png")
pygame.display.set_icon(icon)
SCREEN_UPDATE = pygame.USEREVENT
pygame.time.set_timer(SCREEN_UPDATE, 150)
isStart = True
clock = pygame.time.Clock()
blackColor = pygame.Color('#000000')
game_font = pygame.font.Font('Font/PoetsenOne-Regular.ttf', 25)
game_font_large = pygame.font.Font('Font/PoetsenOne-Regular.ttf', 55)
newScore = False
score = 0

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == SCREEN_UPDATE:
            main_game.update()
        if event.type == pygame.KEYDOWN:
            isStart = False
            if main_game.snake.isDie and event.key == pygame.K_SPACE:
                main_game.snake.isDie = False
                main_game.game_over()
            if event.key == pygame.K_UP:
                if main_game.snake.direction.y != 1:
                    main_game.snake.direction = Vector2(0, -1)
            if event.key == pygame.K_RIGHT:
                if main_game.snake.direction.x != -1:
                    main_game.snake.direction = Vector2(1, 0)
            if event.key == pygame.K_DOWN:
                if main_game.snake.direction.y != -1:
                    main_game.snake.direction = Vector2(0, 1)
            if event.key == pygame.K_LEFT:
                if main_game.snake.direction.x != 1:
                    main_game.snake.direction = Vector2(-1, 0)

    snake.screen.fill((175, 215, 70))
    if isStart:
        main_game.draw_start_game()
    else:
        main_game.draw_elements()
    if main_game.snake.isDie:
        message2 = game_font_large.render("Score: " + main_game.sc, True, blackColor)
        rect2 = message2.get_rect(center=(snake.screen.get_width() / 2, 100))
        snake.screen.blit(message2, rect2)

        message = game_font.render('YOU DIE', True, blackColor)
        rect = message.get_rect(center=(snake.screen.get_width() / 2, snake.screen.get_height() / 2))
        snake.screen.blit(message, rect)

        message1 = game_font.render('Press SPACE key to play game', True, blackColor)
        rect1 = message1.get_rect(center=(snake.screen.get_width() / 2, snake.screen.get_height() / 2 + 100))
        snake.screen.blit(message1, rect1)
        # with open("score.txt", "r") as f_read:
        #     a = int(f_read.read())
        #     if a < int(main_game.sc):
        #         score = a
        #         with open("score.txt", "w") as f_write:
        #             f_write.write(str(main_game.sc))
        if score < int(main_game.sc):
            message3 = game_font.render('New score: ' + main_game.sc, True, blackColor)
            rect3 = message3.get_rect(center=(snake.screen.get_width() / 2, snake.screen.get_height() / 2 - 100))
            snake.screen.blit(message3, rect3)
    pygame.display.update()

    clock.tick(60)
