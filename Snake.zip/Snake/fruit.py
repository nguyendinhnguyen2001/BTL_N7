import pygame
import random
import snake
from pygame.math import Vector2


class FRUIT:
    def __init__(self):
        self.randomize()

     # cho ở vị trí quả táo xuất hiện ở vị trí ngẫu nhiên 
    def randomize(self):
        self.x = random.randint(0, snake.cell_number - 1)
        self.y = random.randint(0, snake.cell_number - 1)
        self.pos = Vector2(self.x, self.y)

    # vẽ quả táo 
    def draw_fruit(self):
        fruit_rect = pygame.Rect(int(self.pos.x * snake.cell_size), int(self.pos.y * snake.cell_size), snake.cell_size,
                                 snake.cell_size)
        snake.screen.blit(snake.apple, fruit_rect)
   
