import pygame
import random
import snake
from pygame.math import Vector2


class ITEM:
    def __init__(self, option):
        self.randomize()
        self.option = option

    def draw_fruit(self):
        if self.option == 0:
            item_rect = pygame.Rect(int(self.pos.x * snake.cell_size), int(self.pos.y * snake.cell_size), snake.cell_size,
                                    snake.cell_size)
            snake.screen.blit(snake.mango, item_rect)
        elif self.option == 1:
            item_rect = pygame.Rect(int(self.pos.x * snake.cell_size), int(self.pos.y * snake.cell_size), snake.cell_size,
                                    snake.cell_size)
            snake.screen.blit(snake.orange, item_rect)
        elif self.option == 2:
            item_rect = pygame.Rect(int(self.pos.x * snake.cell_size), int(self.pos.y * snake.cell_size), snake.cell_size,
                                    snake.cell_size)
            snake.screen.blit(snake.boom, item_rect)

    def randomize(self):
        self.x = random.randint(0, snake.cell_number - 1)
        self.y = random.randint(0, snake.cell_number - 1)
        self.pos = Vector2(self.x, self.y)