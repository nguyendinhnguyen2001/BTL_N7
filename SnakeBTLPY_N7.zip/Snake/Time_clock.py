import snake
import pygame


class Time(object):
    def __init__(self):
        self.current_time = 7200
        self.maximum_time = 7200
        self.time_length = snake.cell_number*snake.cell_size-64
        self.check_time = False

    def increase_time(self):
        self.current_time += 360

    def get_damage(self, amount):
        if self.current_time > 0:
            self.current_time -= amount
        else:
            self.current_time = 0
            self.check_time = True

    def get_time(self):
        self.current_time = self.maximum_time

    def draw(self, screen):
        pygame.draw.rect(
            screen, (255, 0, 0), (0, snake.cell_number * snake.cell_size, float(self.current_time/self.maximum_time)*self.time_length, snake.cell_number * snake.cell_size))
        pygame.draw.rect(
            screen, (0, 0, 0), (0, snake.cell_number * snake.cell_size, self.time_length, snake.cell_number * snake.cell_size), 2)
