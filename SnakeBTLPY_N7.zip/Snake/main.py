import sys
import pygame
import Time_clock
from pygame.math import Vector2
import snake
import fade

main_game = snake.MAIN()

BLACK = (0, 0, 0)
PINK = (235, 65, 54)
pygame.mixer.pre_init(44100, -16, 2, 512)
pygame.mixer.Sound("Sound/data_GreenForest_CC-BY-SA_by_Metaruka.ogg").play()
pygame.display.set_caption("Rắn săn mồi")
icon = pygame.image.load("Graphics/home1.png")
pygame.display.set_icon(icon)
SCREEN_UPDATE = pygame.USEREVENT
pygame.time.set_timer(SCREEN_UPDATE, 150)
isStart = False
clock = pygame.time.Clock()
blackColor = pygame.Color('#000000')
PinkColor = pygame.Color(PINK)
game_font = pygame.font.Font('Font/PoetsenOne-Regular.ttf', 25)
game_font_large = pygame.font.Font('Font/PoetsenOne-Regular.ttf', 55)
newScore = False
score = 0
intro_fade = fade.ScreenFade(1, BLACK, 10)
death_fade = fade.ScreenFade(2, PINK, 10)
start_intro = False
death_intro = True
run = True
while run:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == SCREEN_UPDATE:
            main_game.update()
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                if main_game.snake.direction.y != 1:
                    main_game.snake.direction = Vector2(0, -1)
            if event.key == pygame.K_RIGHT:
                if main_game.snake.direction.x != -1:
                    main_game.snake.direction = Vector2(1, 0)
            if event.key == pygame.K_DOWN:
                if main_game.snake.direction.y != -1:
                    main_game.snake.direction = Vector2(0, 1)
            if event.key == pygame.K_LEFT:
                if main_game.snake.direction.x != 1:
                    main_game.snake.direction = Vector2(-1, 0)
    snake.screen.fill((175, 215, 70))
    if not isStart:
        main_game.draw_start_game()
        if main_game.check_click() == 1:
            isStart = True
            start_intro = True
    else:
        main_game.draw_elements()
        main_game.time_running()
        main_game.check_collision()
        if start_intro:
            if intro_fade.fade():
                start_intro = False
                intro_fade.fade_counter = 0

    if main_game.snake.isDie:
        if death_intro:
            if death_fade.fade():
                death_fade.fade_counter = 0
                death_intro = False

        else:
            main_game.draw_end_game()
            if main_game.snake.isDie and main_game.check_click() == 2:
                death_intro = True
                start_intro = True
                isStart = True
                main_game.time.get_time()
                main_game.snake.isDie = False
                main_game.game_over()
                main_game.eat_item = False
                main_game.k = [0, 0, 0, 0]
                main_game.checkItem = 0
                main_game.time.check_time = False

            if main_game.check_click() == 3:
                run = False

            if score < int(main_game.sc):
                message3 = game_font.render(
                    'New Score: ' + main_game.sc, True, PinkColor)
                rect3 = message3.get_rect(
                    center=(snake.screen.get_width() / 2, 300))
                snake.screen.blit(message3, rect3)
                score = int(main_game.sc)
            else:
                message2 = game_font_large.render(
                    "Score: " + main_game.sc, True, PinkColor)
                rect2 = message2.get_rect(
                    center=(snake.screen.get_width() / 2, 300))
                snake.screen.blit(message2, rect2)
    pygame.display.update()
    clock.tick(60)
pygame.quit()
